package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.List _jspx_dependants;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html>\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<title>Birlasoft OCUCT Test Engine</title>\r\n");
      out.write("\r\n");
      out.write("<meta charset=\"utf-8\">\r\n");
      out.write("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n");
      out.write("<meta name=\"keywords\" content=\"Slide Login Form template Responsive, Login form web template, Flat Pricing tables, Flat Drop downs Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />\r\n");
      out.write("\r\n");
      out.write("\t <script>\r\n");
      out.write("        addEventListener(\"load\", function () {\r\n");
      out.write("            setTimeout(hideURLbar, 0);\r\n");
      out.write("        }, false);\r\n");
      out.write("\r\n");
      out.write("        function hideURLbar() {\r\n");
      out.write("            window.scrollTo(0, 1);\r\n");
      out.write("        }\r\n");
      out.write("    </script>\r\n");
      out.write("\r\n");
      out.write("\t<!-- Custom Theme files -->\r\n");
      out.write("\t<link href=\"css2/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />\r\n");
      out.write("\t<link href=\"css2/font-awesome.min.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />\r\n");
      out.write("\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js\"></script>\r\n");
      out.write("\r\n");
      out.write("\t<!-- //Custom Theme files -->\r\n");
      out.write("\r\n");
      out.write("\t<!-- web font -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("\r\n");
      out.write("<!-- main -->\r\n");
      out.write("<div class=\"w3layouts-main\"> \r\n");
      out.write("\t<div class=\"bg-layer\"><br>\r\n");
      out.write("\t\t\t\t<center><img src=\"images/logo.png\" width=\"300px\" height=\"67px\"></center>\r\n");
      out.write("<h1> Ocust Test Engine Login</h1>\r\n");
      out.write("\t\t<div class=\"header-main\">\r\n");
      out.write("\t\t\t<div class=\"main-icon\">\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div class=\"header-left-bottom\">\r\n");
      out.write("\t\t\t\t<form>\r\n");
      out.write("\t\t\t\t\t<div class=\"icon1 wthree-field\">\r\n");
      out.write("\t\t\t\t\t\t<span class=\"fa fa-user\"></span>\r\n");
      out.write("\t\t\t\t\t\t<input style=\"background:transparent; border:none;box-sizing: border-box;\" type=\"text\" id=\"txtempname\" placeholder=\"User Name\" value\t required=\"\"/>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t<div class=\"icon1\">\r\n");
      out.write("\t\t\t\t\t\t<span class=\"fa fa-lock\"></span>\r\n");
      out.write("\t\t\t\t\t\t<input type=\"password\" id=\"txtdesignation\" placeholder=\"Password\" required=\"\"/>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t<div class=\"bottom\">\r\n");
      out.write("\t\t\t\t\t\t<button onclick=\"login();\" class=\"btn\">Log In</button>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t<div class=\"links\">\r\n");
      out.write("\t\t\t\t\t\t<p><a href=\"#\">Forgot Password?</a></p>\r\n");
      out.write("\t\t\t\t\t\t<p class=\"right\"><a href=\"#\">New User? Register</a></p>\r\n");
      out.write("\t\t\t\t\t\t<div class=\"clear\"></div>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t</form>\t\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<!-- copyright -->\r\n");
      out.write("\t\t<div class=\"footer\">\r\n");
      out.write("\t\t<p>&copy; BIRLASOFT LIMITED. All Rights Reserved  <a href=\"#\">BIRLASOFT</a></p>\r\n");
      out.write("\t</div>\r\n");
      out.write("\t\t<!-- //copyright --> \r\n");
      out.write("\t</div>\r\n");
      out.write("</div>\t\r\n");
      out.write("<!-- //main -->\r\n");
      out.write("\r\n");
      out.write("<script>\r\n");
      out.write("\r\n");
      out.write("function login(){\r\n");
      out.write("\r\n");
      out.write("\tvar uName = $('#txtempname').val();\r\n");
      out.write("\tvar paswd = $('#txtdesignation').val();\r\n");
      out.write("\r\n");
      out.write("\tif(uName===\"admin\" && paswd===\"ocust\"){\r\n");
      out.write("\t\twindow.open(\"home.html\")\r\n");
      out.write("\t\r\n");
      out.write("\t}\r\n");
      out.write("\telse{\r\n");
      out.write("\talert(\"Invalid Credentials\");\r\n");
      out.write("\t}\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("</script>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
